/**
 * AcademyForge Deterministic SCORM 1.2 Runtime API Adapter
 * Compatible with Canvas, Moodle, Blackboard, Docebo, Cornerstone, and standalone preview.
 */
(function (global) {
  'use strict';
  var apiHandle = null;
  var initialized = false;
  var localStore = {
    'cmi.core.lesson_status': 'not attempted',
    'cmi.core.score.min': '0',
    'cmi.core.score.max': '100',
    'cmi.core.score.raw': '0'
  };

  function findApi(win) {
    var depth = 0;
    while (win && !win.API && win.parent && win.parent !== win && depth < 10) {
      depth += 1;
      win = win.parent;
    }
    return (win && win.API) ? win.API : null;
  }

  function getApi() {
    if (apiHandle) return apiHandle;
    apiHandle = findApi(global) || (global.opener ? findApi(global.opener) : null);
    return apiHandle;
  }

  global.AcademyForgeSCORM = {
    init: function () {
      var api = getApi();
      if (api && !initialized) {
        api.LMSInitialize('');
        initialized = true;
        api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
        api.LMSCommit('');
        return 'connected';
      }
      initialized = true;
      return 'standalone_preview';
    },
    recordScore: function (rawScore, masteryScore) {
      var score = Math.max(0, Math.min(100, Number(rawScore) || 0));
      var status = score >= (masteryScore || 80) ? 'passed' : 'failed';
      localStore['cmi.core.score.raw'] = String(score);
      localStore['cmi.core.lesson_status'] = status;
      var api = getApi();
      if (api) {
        api.LMSSetValue('cmi.core.score.min', '0');
        api.LMSSetValue('cmi.core.score.max', '100');
        api.LMSSetValue('cmi.core.score.raw', String(score));
        api.LMSSetValue('cmi.core.lesson_status', status);
        api.LMSCommit('');
      }
      return { score: score, status: status, lmsBound: Boolean(api) };
    },
    finish: function () {
      var api = getApi();
      if (api && initialized) {
        api.LMSCommit('');
        api.LMSFinish('');
      }
      initialized = false;
    }
  };
})(window);
